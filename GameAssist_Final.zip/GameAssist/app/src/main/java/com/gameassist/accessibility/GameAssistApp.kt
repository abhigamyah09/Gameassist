package com.gameassist.accessibility
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
class GameAssistApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "gameassist_service", "GameAssist Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Keeps the assist running while you play." }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
