package com.gameassist.accessibility.service
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import com.gameassist.accessibility.overlay.OverlayManager
import com.gameassist.accessibility.util.GameAssistPrefs

class GameAssistService : AccessibilityService() {
    companion object {
        @Volatile var instance: GameAssistService? = null
        fun isActive() = instance != null
        fun toggle() = instance?.toggleAssist()
    }
    private var overlay: OverlayManager? = null
    private var detector: ColorDetector? = null
    private var analyzer: ThreatAnalyzer? = null
    private var gesture: GestureEngine? = null
    private var tracker: PlayerTracker? = null
    private var calibrator: AutoCalibrator? = null
    private var captureManager: ScreenCaptureManager? = null
    private var enabled = false
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: GameAssistPrefs
    private var screenW = 0; private var screenH = 0

    private val loop = object : Runnable {
        override fun run() {
            runFrame()
            if (enabled) handler.postDelayed(this, 100L)
        }
    }

    override fun onServiceConnected() {
        instance = this
        prefs = GameAssistPrefs(this)
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val m = DisplayMetrics(); @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
        screenW = m.widthPixels; screenH = m.heightPixels
        detector = ColorDetector(screenW)
        analyzer = ThreatAnalyzer(screenW, screenH)
        gesture = GestureEngine(this, screenW).apply { currentY = screenH * 0.85f }
        tracker = PlayerTracker(screenW, screenH)
        calibrator = AutoCalibrator(prefs.calibDurationSec)
        captureManager = ScreenCaptureManager(this)
        overlay = OverlayManager(this) { toggleAssist() }
        overlay?.show()
    }

    fun startCapture(resultCode: Int, data: Intent) {
        captureManager?.start(resultCode, data)
    }

    private fun toggleAssist() {
        if (enabled) { enabled = false; handler.removeCallbacks(loop); overlay?.setOn(false) }
        else if (captureManager?.isRunning == true) { enabled = true; handler.post(loop); overlay?.setOn(true) }
    }

    private fun runFrame() {
        val bmp = captureManager?.latestBitmap ?: return
        calibrator?.feed(bmp)
        val blobs = detector?.detect(bmp) ?: return
        val px = tracker?.x ?: (screenW / 2f)
        val action = analyzer?.analyze(px, blobs) ?: return
        if (action.urgency > 0f && gesture?.busy == false) {
            gesture?.moveTo(action.targetX, action.targetY, action.urgency, prefs.speedFraction, prefs.minIntervalMs)
        }
        overlay?.updateStatus(action.label)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean {
        instance = null; overlay?.hide(); handler.removeCallbacks(loop)
        return super.onUnbind(intent)
    }
}
