package com.gameassist.accessibility.overlay
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.*
import android.widget.TextView
import com.gameassist.accessibility.R

class OverlayManager(private val ctx: Context, private val onToggle: () -> Unit) {
    private var wm: WindowManager? = null
    private var root: View? = null
    private var fab: View? = null
    private var pill: TextView? = null
    private var on = false

    fun show() {
        wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val inflater = LayoutInflater.from(ctx)
        root = inflater.inflate(R.layout.overlay_button, null)
        fab = root?.findViewById(R.id.fab)
        pill = root?.findViewById(R.id.status_pill)
        fab?.setOnClickListener { onToggle() }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 50; y = 300 }
        wm?.addView(root, params)
    }

    fun setOn(state: Boolean) {
        on = state
        fab?.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (on) 0xFF1565C0.toInt() else 0xFF9E9E9E.toInt())
        pill?.text = if (on) "Scanning…" else "OFF"
    }

    fun updateStatus(label: String) { pill?.text = label }
    fun hide() { root?.let { wm?.removeView(it) }; root = null }
}
