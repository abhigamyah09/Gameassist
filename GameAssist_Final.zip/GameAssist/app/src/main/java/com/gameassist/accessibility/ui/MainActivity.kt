package com.gameassist.accessibility.ui
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.gameassist.accessibility.R
import com.gameassist.accessibility.service.GameAssistService

class MainActivity : AppCompatActivity() {
    private val REQ_CAPTURE = 1001
    private lateinit var tvAccess: TextView
    private lateinit var tvOverlay: TextView
    private lateinit var tvCapture: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvAccess = findViewById(R.id.status_accessibility)
        tvOverlay = findViewById(R.id.status_overlay)
        tvCapture = findViewById(R.id.status_capture)
        findViewById<Button>(R.id.btn_open_accessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btn_open_overlay).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this))
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else Toast.makeText(this, "Already granted!", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btn_start_capture).setOnClickListener {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE)
        }
        findViewById<Button>(R.id.btn_launch_demo).setOnClickListener {
            startActivity(Intent(this, com.gameassist.accessibility.demo.MeteorDodgeActivity::class.java))
        }
        findViewById<Button>(R.id.btn_open_settings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() { super.onResume(); updateStatus() }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            GameAssistService.instance?.startCapture(resultCode, data)
            Toast.makeText(this, "Capture started! Go play the game.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateStatus() {
        val hasAccess = isAccessibilityEnabled()
        val hasOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(this) else true
        tvAccess.text = if (hasAccess) getString(R.string.status_accessibility_granted) else getString(R.string.status_accessibility_missing)
        tvOverlay.text = if (hasOverlay) getString(R.string.status_overlay_granted) else getString(R.string.status_overlay_missing)
        tvCapture.text = getString(R.string.status_capture_missing)
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName }
    }
}
