package com.gameassist.accessibility.service

class PlayerTracker(private val screenW: Int, private val screenH: Int) {
    private val alpha = 0.3f
    var x = screenW / 2f; private set
    var y = screenH * 0.85f; private set
    private var initialized = false

    fun update(newX: Float, newY: Float) {
        x = if (!initialized) newX else x + alpha * (newX - x)
        y = if (!initialized) newY else y + alpha * (newY - y)
        initialized = true
    }
    fun reset() { x = screenW/2f; y = screenH*0.85f; initialized = false }
}
