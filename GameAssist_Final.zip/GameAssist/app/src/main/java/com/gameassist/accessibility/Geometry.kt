package com.gameassist.accessibility
import android.graphics.RectF
enum class ThreatZone { LEFT, CENTER, RIGHT, NONE }
data class Blob(val zone: ThreatZone, val centerX: Float, val centerY: Float, val bounds: RectF, val area: Int)
data class AssistAction(val targetX: Float, val targetY: Float, val urgency: Float, val label: String)
