package com.gameassist.accessibility.util

import android.graphics.Color
import kotlin.math.sqrt

object ColorUtils {
    fun isMeteor(pixel: Int): Boolean {
        val hsv = FloatArray(3)
        Color.colorToHSV(pixel, hsv)
        return (hsv[0] <= 40f || hsv[0] >= 340f) && hsv[1] >= 0.50f && hsv[2] >= 0.40f
    }
    fun isUFO(pixel: Int): Boolean {
        val hsv = FloatArray(3)
        Color.colorToHSV(pixel, hsv)
        return hsv[0] in 190f..260f && hsv[1] >= 0.35f && hsv[2] >= 0.30f
    }
    fun isCollectible(pixel: Int): Boolean {
        val hsv = FloatArray(3)
        Color.colorToHSV(pixel, hsv)
        return hsv[1] <= 0.18f && hsv[2] >= 0.70f
    }
    fun rgbDistance(a: Int, b: Int): Double {
        val dr = (Color.red(a) - Color.red(b)).toDouble()
        val dg = (Color.green(a) - Color.green(b)).toDouble()
        val db = (Color.blue(a) - Color.blue(b)).toDouble()
        return sqrt(dr*dr + dg*dg + db*db)
    }
    fun isClose(a: Int, b: Int, threshold: Double = 40.0) = rgbDistance(a, b) < threshold
}
