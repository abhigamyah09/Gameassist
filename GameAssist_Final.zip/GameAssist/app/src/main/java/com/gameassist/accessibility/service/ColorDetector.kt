package com.gameassist.accessibility.service
import android.graphics.Bitmap
import com.gameassist.accessibility.Blob
import com.gameassist.accessibility.ThreatZone
import com.gameassist.accessibility.util.ColorUtils
import android.graphics.RectF

class ColorDetector(private val screenW: Int) {
    private val STEP = 4
    data class FrameBlobs(val meteors: List<Blob>, val ufos: List<Blob>, val collectibles: List<Blob>)

    fun detect(bmp: Bitmap): FrameBlobs {
        val meteors = mutableListOf<Blob>()
        val ufos = mutableListOf<Blob>()
        val cols = mutableListOf<Blob>()
        val w = bmp.width; val h = bmp.height
        val third = w / 3f
        data class Cell(var sumX: Float=0f, var sumY: Float=0f, var count: Int=0, var minX: Float=Float.MAX_VALUE, var minY: Float=Float.MAX_VALUE, var maxX: Float=0f, var maxY: Float=0f)
        val mCells = Array(9){Cell()}; val uCells = Array(9){Cell()}; val cCells = Array(9){Cell()}
        for (y in 0 until h step STEP) for (x in 0 until w step STEP) {
            val p = bmp.getPixel(x, y)
            val ci = (x/(w/3f)).toInt().coerceIn(0,2) + (y/(h/3f)).toInt().coerceIn(0,2)*3
            fun Cell.add() { sumX+=x; sumY+=y; count++; if(x<minX)minX=x.toFloat(); if(y<minY)minY=y.toFloat(); if(x>maxX)maxX=x.toFloat(); if(y>maxY)maxY=y.toFloat() }
            when { ColorUtils.isMeteor(p)->mCells[ci].add(); ColorUtils.isUFO(p)->uCells[ci].add(); ColorUtils.isCollectible(p)->cCells[ci].add() }
        }
        fun Array<Cell>.toBlobs(type: String) = filter{it.count>8}.map{ c ->
            val cx = c.sumX/c.count; val zone = when { cx<third->ThreatZone.LEFT; cx>w-third->ThreatZone.RIGHT; else->ThreatZone.CENTER }
            Blob(zone, cx, c.sumY/c.count, RectF(c.minX,c.minY,c.maxX,c.maxY), c.count)
        }
        return FrameBlobs(mCells.toBlobs("meteor"), uCells.toBlobs("ufo"), cCells.toBlobs("col"))
    }
}
